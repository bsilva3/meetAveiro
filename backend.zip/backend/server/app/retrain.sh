#!/bin/bash
cd "../../../scripts_tensorflow"
sh "./retrain"